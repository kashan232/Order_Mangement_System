
<script src="/Order_Booker_System/assets/js/jquery-3.7.1.min.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
    <script src="/Order_Booker_System/assets/js/bootstrap.bundle.min.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
	<script src="/Order_Booker_System/assets/js/feather.min.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
    <script src="/Order_Booker_System/assets/js/jquery.slimscroll.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
	<script src="/Order_Booker_System/assets/js/select2.min.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
	<script src="/Order_Booker_System/assets/plugins/datatables/jquery.dataTables.min.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
	<script src="/Order_Booker_System/assets/plugins/datatables/datatables.min.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
	<script src="/Order_Booker_System/assets/js/jquery.waypoints.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
	<script src="/Order_Booker_System/assets/js/jquery.counterup.min.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
	<script src="/Order_Booker_System/assets/plugins/apexchart/apexcharts.min.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
	<script src="/Order_Booker_System/assets/plugins/apexchart/chart-data.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
    <script src="/Order_Booker_System/assets/js/app.js" type="df52c4bbdaa9438d6b34d442-text/javascript"></script>
    <script src="/Order_Booker_System/assets/js/rocket-loader.min.js" data-cf-settings="df52c4bbdaa9438d6b34d442-|49" defer></script></body>


	
</body>

</html>