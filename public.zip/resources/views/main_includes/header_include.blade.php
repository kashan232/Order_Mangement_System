<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="/Order_Booker_System/assets/img/favicon.png">
    <title>Order Booker System</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/Order_Booker_System/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Order_Booker_System/assets/plugins/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="/Order_Booker_System/assets/plugins/fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="/Order_Booker_System/assets/css/select2.min.css">
    <link rel="stylesheet" href="/Order_Booker_System/assets/plugins/datatables/datatables.min.css">
    <link rel="stylesheet" href="/Order_Booker_System/assets/css/feather.css">
    <link rel="stylesheet" type="text/css" href="/Order_Booker_System/assets/css/style.css">


</head>

<body>